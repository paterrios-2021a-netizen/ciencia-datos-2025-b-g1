import streamlit as st
import pandas as pd
import plotly.express as px
import matplotlib.pyplot as plt
import os
import random

# -------------------------------------------------
# CONFIGURACIÓN DE LA PÁGINA
# -------------------------------------------------
st.set_page_config(page_title="Ventas Jardinería", layout="wide")
st.title("🌿 Ventas de Productos de una Jardinería")
st.write("Garden-Women")

# -------------------------------------------------
# CARGA DE DATOS CON CACHE
# -------------------------------------------------
@st.cache_data
def load_data():
    csv_path = "jardineria.csv"
    if not os.path.exists(csv_path):
        st.error(f" El archivo '{csv_path}' no existe en la carpeta del proyecto.")
        st.stop()
    return pd.read_csv(csv_path, encoding="latin1")

df = load_data()

# -------------------------------------------------
# VALIDACIÓN DE COLUMNAS
# -------------------------------------------------
columnas_necesarias = ["Region", "Producto", "Cantidad", "PrecioUnitario"]

for col in columnas_necesarias:
    if col not in df.columns:
        
        if col == "Cantidad":
            df[col] = 1
        elif col == "PrecioUnitario":
            df[col] = 1.0
        elif col == "Region":
            df[col] = "Norte"   # región por defecto
        else:
            df[col] = "Desconocido"

# -------------------------------------------------
# FORZAR QUE TODAS LAS REGIONES SEAN NORTE, SUR, ORIENTE U OCCIDENTE
# -------------------------------------------------
regiones_validas = ["Norte", "Sur", "Oeste", "Este", "centro"]

# Si alguna región no coincide, se asigna al azar
df["Region"] = df["Region"].apply(lambda x: x if x in regiones_validas else random.choice(regiones_validas))

# Crear columna TotalVenta si no existe
if "TotalVenta" not in df.columns:
    df["TotalVenta"] = df["Cantidad"] * df["PrecioUnitario"]

# -------------------------------------------------
# TABLA COMPLETA
# -------------------------------------------------
st.subheader(" Tabla de Datos")
st.dataframe(df, use_container_width=True)

# -------------------------------------------------
# FILTROS LATERALES
# -------------------------------------------------
st.sidebar.header(" Filtros")

region_filtro = st.sidebar.selectbox(
    "Filtrar por región:",
    ["Todos"] + regiones_validas
)

productos_sidebar = st.sidebar.multiselect(
    "Filtrar productos en los gráficos:",
    options=sorted(df["Producto"].unique().tolist()),
    default=sorted(df["Producto"].unique().tolist())
)

df_filtrado_general = df.copy()

if region_filtro != "Todos":
    df_filtrado_general = df_filtrado_general[df_filtrado_general["Region"] == region_filtro]

# -------------------------------------------------
# TABLA FILTRADA CON SELECTOR PROPIO
# -------------------------------------------------
st.subheader(" Tabla filtrada por producto")

producto_tabla_select = st.selectbox(
    "Selecciona un producto para mostrar en la tabla:",
    ["Todos"] + sorted(df["Producto"].unique().tolist())
)

df_tabla = df_filtrado_general.copy()

if producto_tabla_select != "Todos":
    df_tabla = df_tabla[df_tabla["Producto"] == producto_tabla_select]

st.dataframe(df_tabla, use_container_width=True)

# ============================
# GRAFICO DE REGIONES 
# ============================

import plotly.express as px
import pandas as pd

# Porcentajes personalizados (PUEDES CAMBIARLOS)
df_regiones = pd.DataFrame({
    "Region": ["Norte", "Sur", "Este", "Oeste", "Centro"],
    "Porcentaje": [40, 20, 15, 10, 15]   # <<< CAMBIA ESTO COMO QUIERAS
})

# Gráfico circular
fig_regiones = px.pie(
    df_regiones,
    names="Region",
    values="Porcentaje",
    title="Participación de Ventas por Región (Porcentajes Definidos Manualmente)"
)

# Mostrar valores en etiqueta
fig_regiones.update_traces(
    textinfo="label+percent",
    textposition="inside"
)

st.plotly_chart(fig_regiones)

# -------------------------------------------------
# GRÁFICO: VENTAS POR PRODUCTO
# -------------------------------------------------
st.subheader(" Ventas por Producto")

df_productos = df_filtrado_general[df_filtrado_general["Producto"].isin(productos_sidebar)]

ventas_producto = df_productos.groupby("Producto")["TotalVenta"].sum().sort_values(ascending=False)

fig2, ax2 = plt.subplots(figsize=(10, 5))
ventas_producto.plot(kind='bar', ax=ax2)
ax2.set_title("Ventas por Producto", fontsize=16)
ax2.set_ylabel("Total de Ventas")
plt.xticks(rotation=90)
plt.tight_layout()

st.pyplot(fig2)

# -------------------------------------------------
# MÉTRICAS
# -------------------------------------------------
st.subheader(" Resumen de Ventas")

col1, col2 = st.columns(2)

col1.metric(" Total Ventas", f"${df_filtrado_general['TotalVenta'].sum():,.0f}")
col2.metric(" Total Productos Vendidos", df_filtrado_general["Cantidad"].sum())
